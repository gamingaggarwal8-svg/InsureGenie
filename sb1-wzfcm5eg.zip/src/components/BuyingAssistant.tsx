import { useState } from 'react';
import { CheckCircle, XCircle, AlertTriangle, TrendingUp, DollarSign, Lightbulb } from 'lucide-react';
import { Button } from './Button';
import { Card } from './Card';

interface InsuranceItem {
  title: string;
  description: string;
  cost: string;
  required?: boolean;
  why?: string;
  worthIt?: boolean | string;
  when?: string;
  reason?: string;
}

interface BuyingGuidance {
  mandatory: InsuranceItem[];
  recommended: InsuranceItem[];
  optional: InsuranceItem[];
  avoid: InsuranceItem[];
  steps: string[];
  estimatedCost: {
    minimum: string;
    recommended: string;
    note: string;
  };
  tips: string[];
}

export function BuyingAssistant() {
  const [context, setContext] = useState('');
  const [loading, setLoading] = useState(false);
  const [guidance, setGuidance] = useState<BuyingGuidance | null>(null);

  const handleGetAdvice = async () => {
    if (!context.trim()) return;

    setLoading(true);
    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/buying-assistant`;
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          context: context
        })
      });

      const data = await response.json();
      setGuidance(data);
    } catch (error) {
      console.error('Error getting advice:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <Card>
        <h2 className="text-2xl font-bold text-gray-800 mb-6">Insurance Buying Assistant</h2>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Describe Your Situation
            </label>
            <textarea
              value={context}
              onChange={(e) => setContext(e.target.value)}
              placeholder="E.g., I just bought a new Honda City worth ₹12 lakhs..."
              rows={4}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
            />
          </div>

          <Button
            onClick={handleGetAdvice}
            disabled={!context.trim() || loading}
            fullWidth
          >
            {loading ? 'Getting Advice...' : 'Get Personalized Advice'}
          </Button>
        </div>
      </Card>

      {guidance && (
        <>
          <Card className="bg-blue-50 border-2 border-blue-200">
            <h3 className="text-xl font-bold text-blue-800 mb-4 flex items-center gap-2">
              <CheckCircle className="w-6 h-6" />
              Mandatory Insurance (Required by Law)
            </h3>
            <div className="space-y-4">
              {guidance.mandatory.map((item, idx) => (
                <div key={idx} className="bg-white p-4 rounded-lg">
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="font-bold text-gray-800">{item.title}</h4>
                    <span className="text-sm font-medium text-blue-600">{item.cost}</span>
                  </div>
                  <p className="text-gray-600 text-sm">{item.description}</p>
                </div>
              ))}
            </div>
          </Card>

          <Card className="bg-green-50 border-2 border-green-200">
            <h3 className="text-xl font-bold text-green-800 mb-4 flex items-center gap-2">
              <TrendingUp className="w-6 h-6" />
              Recommended Coverage
            </h3>
            <div className="space-y-4">
              {guidance.recommended.map((item, idx) => (
                <div key={idx} className="bg-white p-4 rounded-lg">
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="font-bold text-gray-800">{item.title}</h4>
                    <span className="text-sm font-medium text-green-600">{item.cost}</span>
                  </div>
                  <p className="text-gray-600 text-sm mb-2">{item.description}</p>
                  {item.why && (
                    <p className="text-green-700 text-sm font-medium">
                      <strong>Why:</strong> {item.why}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </Card>

          <Card>
            <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
              <AlertTriangle className="w-6 h-6 text-yellow-600" />
              Optional Add-ons (Consider Based on Needs)
            </h3>
            <div className="space-y-4">
              {guidance.optional.map((item, idx) => (
                <div key={idx} className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="font-bold text-gray-800">{item.title}</h4>
                    <span className="text-sm font-medium text-gray-600">{item.cost}</span>
                  </div>
                  <p className="text-gray-600 text-sm mb-2">{item.description}</p>
                  {item.when && (
                    <p className="text-yellow-700 text-sm">
                      <strong>Consider if:</strong> {item.when}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </Card>

          <Card className="bg-red-50 border-2 border-red-200">
            <h3 className="text-xl font-bold text-red-800 mb-4 flex items-center gap-2">
              <XCircle className="w-6 h-6" />
              What to Avoid
            </h3>
            <div className="space-y-4">
              {guidance.avoid.map((item, idx) => (
                <div key={idx} className="bg-white p-4 rounded-lg">
                  <h4 className="font-bold text-gray-800 mb-2">{item.title}</h4>
                  <p className="text-gray-600 text-sm mb-2">{item.description}</p>
                  <p className="text-red-700 text-sm font-medium">
                    <strong>Why avoid:</strong> {item.reason}
                  </p>
                </div>
              ))}
            </div>
          </Card>

          <Card>
            <h3 className="text-xl font-bold text-gray-800 mb-4">Purchase Steps</h3>
            <ol className="space-y-3">
              {guidance.steps.map((step, idx) => (
                <li key={idx} className="flex gap-3">
                  <span className="flex-shrink-0 w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold">
                    {idx + 1}
                  </span>
                  <span className="text-gray-700 pt-1">{step}</span>
                </li>
              ))}
            </ol>
          </Card>

          <Card className="bg-gradient-to-r from-blue-50 to-green-50">
            <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
              <DollarSign className="w-6 h-6 text-green-600" />
              Estimated Cost
            </h3>
            <div className="space-y-2">
              <p className="text-gray-700">
                <strong>Minimum (mandatory only):</strong> {guidance.estimatedCost.minimum}
              </p>
              <p className="text-gray-700">
                <strong>Recommended:</strong> {guidance.estimatedCost.recommended}
              </p>
              <p className="text-sm text-gray-600 mt-3">{guidance.estimatedCost.note}</p>
            </div>
          </Card>

          <Card className="bg-yellow-50">
            <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
              <Lightbulb className="w-6 h-6 text-yellow-600" />
              Pro Tips
            </h3>
            <ul className="space-y-2">
              {guidance.tips.map((tip, idx) => (
                <li key={idx} className="text-gray-700 flex items-start gap-2">
                  <span className="text-yellow-600">💡</span>
                  {tip}
                </li>
              ))}
            </ul>
          </Card>
        </>
      )}
    </div>
  );
}
