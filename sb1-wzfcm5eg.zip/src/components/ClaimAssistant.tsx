import { useState } from 'react';
import { Upload, AlertCircle, CheckCircle, Clock, FileText } from 'lucide-react';
import { Button } from './Button';
import { Card } from './Card';

interface ClaimAnalysis {
  readinessScore: number;
  steps: string[];
  requiredDocuments: string[];
  priorityActions: string[];
  warnings: string[];
  timeline: string;
  checklist: { item: string; status: 'complete' | 'missing' | 'pending' }[];
}

export function ClaimAssistant() {
  const [file, setFile] = useState<File | null>(null);
  const [incident, setIncident] = useState('Car Accident');
  const [loading, setLoading] = useState(false);
  const [analysis, setAnalysis] = useState<ClaimAnalysis | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleAnalyze = async () => {
    if (!file) return;

    setLoading(true);
    try {
      const text = await file.text();

      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/analyze-claim`;
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          policyText: text,
          incident: incident
        })
      });

      const data = await response.json();
      setAnalysis(data);
    } catch (error) {
      console.error('Error analyzing claim:', error);
    } finally {
      setLoading(false);
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getStatusIcon = (status: string) => {
    if (status === 'complete') return <CheckCircle className="w-5 h-5 text-green-500" />;
    if (status === 'pending') return <Clock className="w-5 h-5 text-yellow-500" />;
    return <AlertCircle className="w-5 h-5 text-red-500" />;
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <Card>
        <h2 className="text-2xl font-bold text-gray-800 mb-6">Claim Assistance</h2>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Upload Insurance Document
            </label>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-blue-400 transition-colors">
              <input
                type="file"
                onChange={handleFileChange}
                accept=".pdf,.txt,.doc,.docx"
                className="hidden"
                id="file-upload"
              />
              <label htmlFor="file-upload" className="cursor-pointer">
                <Upload className="w-12 h-12 mx-auto text-gray-400 mb-3" />
                <p className="text-gray-600">
                  {file ? file.name : 'Click to upload or drag and drop'}
                </p>
                <p className="text-sm text-gray-500 mt-1">PDF, TXT, DOC up to 10MB</p>
              </label>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Incident Type
            </label>
            <select
              value={incident}
              onChange={(e) => setIncident(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option>Car Accident</option>
              <option>Vehicle Theft</option>
              <option>Natural Calamity Damage</option>
              <option>Third-Party Damage</option>
            </select>
          </div>

          <Button
            onClick={handleAnalyze}
            disabled={!file || loading}
            fullWidth
          >
            {loading ? 'Analyzing...' : 'Guide Me'}
          </Button>
        </div>
      </Card>

      {analysis && (
        <>
          <Card>
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-gray-800">Claim Readiness Score</h3>
              <div className={`text-5xl font-bold ${getScoreColor(analysis.readinessScore)}`}>
                {analysis.readinessScore}%
              </div>
            </div>

            <div className="space-y-3">
              {analysis.checklist.map((item, idx) => (
                <div key={idx} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                  {getStatusIcon(item.status)}
                  <span className="text-gray-700">{item.item}</span>
                </div>
              ))}
            </div>
          </Card>

          <Card className="bg-red-50 border-2 border-red-200">
            <h3 className="text-xl font-bold text-red-800 mb-4 flex items-center gap-2">
              <AlertCircle className="w-6 h-6" />
              Priority Actions
            </h3>
            <ul className="space-y-2">
              {analysis.priorityActions.map((action, idx) => (
                <li key={idx} className="text-red-700 font-medium flex items-start gap-2">
                  <span className="text-red-500 font-bold">⚠</span>
                  {action}
                </li>
              ))}
            </ul>
          </Card>

          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                <FileText className="w-6 h-6 text-blue-600" />
                Required Documents
              </h3>
              <ul className="space-y-2">
                {analysis.requiredDocuments.map((doc, idx) => (
                  <li key={idx} className="text-gray-700 flex items-start gap-2">
                    <span className="text-blue-600">•</span>
                    {doc}
                  </li>
                ))}
              </ul>
            </Card>

            <Card>
              <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                <Clock className="w-6 h-6 text-blue-600" />
                Timeline
              </h3>
              <p className="text-gray-700 text-lg">{analysis.timeline}</p>
            </Card>
          </div>

          <Card>
            <h3 className="text-xl font-bold text-gray-800 mb-4">Step-by-Step Process</h3>
            <ol className="space-y-3">
              {analysis.steps.map((step, idx) => (
                <li key={idx} className="flex gap-3">
                  <span className="flex-shrink-0 w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold">
                    {idx + 1}
                  </span>
                  <span className="text-gray-700 pt-1">{step}</span>
                </li>
              ))}
            </ol>
          </Card>

          {analysis.warnings.length > 0 && (
            <Card className="bg-yellow-50 border-2 border-yellow-200">
              <h3 className="text-xl font-bold text-yellow-800 mb-4 flex items-center gap-2">
                <AlertCircle className="w-6 h-6" />
                Important Warnings
              </h3>
              <ul className="space-y-2">
                {analysis.warnings.map((warning, idx) => (
                  <li key={idx} className="text-yellow-700 flex items-start gap-2">
                    <span className="text-yellow-500">⚠</span>
                    {warning}
                  </li>
                ))}
              </ul>
            </Card>
          )}
        </>
      )}
    </div>
  );
}
