import { useState } from 'react';
import { Sparkles, FileText, ShoppingCart } from 'lucide-react';
import { ClaimAssistant } from './components/ClaimAssistant';
import { BuyingAssistant } from './components/BuyingAssistant';

type Mode = 'claim' | 'buying';

function App() {
  const [mode, setMode] = useState<Mode>('claim');

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">
      <header className="bg-white shadow-md border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-br from-blue-600 to-green-600 p-2 rounded-lg">
                <Sparkles className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent">
                  InsureGenie
                </h1>
                <p className="text-sm text-gray-600">Your AI Insurance Decision Copilot</p>
              </div>
            </div>
          </div>

          <div className="flex gap-4 mt-6">
            <button
              onClick={() => setMode('claim')}
              className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all ${
                mode === 'claim'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <FileText className="w-5 h-5" />
              Claim Assistance
            </button>
            <button
              onClick={() => setMode('buying')}
              className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all ${
                mode === 'buying'
                  ? 'bg-green-600 text-white shadow-md'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <ShoppingCart className="w-5 h-5" />
              Buying Assistant
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {mode === 'claim' ? <ClaimAssistant /> : <BuyingAssistant />}
      </main>

      <footer className="bg-white border-t border-gray-200 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <p className="text-center text-gray-600 text-sm">
            InsureGenie provides guidance only. Always verify with your insurance provider for final decisions.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;
