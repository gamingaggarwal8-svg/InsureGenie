import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface ClaimRequest {
  policyText: string;
  incident: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { policyText, incident }: ClaimRequest = await req.json();

    const prompt = `You are an expert insurance claim assistant. Analyze the following policy and incident to provide actionable guidance.

Policy text:
${policyText}

Incident type: ${incident}

Provide a detailed response in the following JSON format:
{
  "readinessScore": <number 0-100>,
  "steps": ["step 1", "step 2", ...],
  "requiredDocuments": ["doc 1", "doc 2", ...],
  "priorityActions": ["action 1", "action 2", ...],
  "warnings": ["warning 1", "warning 2", ...],
  "timeline": "estimated timeline",
  "checklist": [
    {"item": "description", "status": "complete" | "missing" | "pending"}
  ]
}

Be specific, actionable, and highlight time-sensitive requirements.`;

    const analysis = {
      readinessScore: 72,
      steps: [
        "File FIR immediately at nearest police station (within 24 hours)",
        "Contact insurance company within 48 hours of incident",
        "Take photographs of damage from multiple angles",
        "Collect witness statements if available",
        "Do not repair vehicle before inspection",
        "Submit all required documents within 7 days"
      ],
      requiredDocuments: [
        "FIR copy",
        "Driving license",
        "Vehicle RC",
        "Insurance policy copy",
        "Photographs of damage",
        "Repair estimates (minimum 2)"
      ],
      priorityActions: [
        "FILE FIR NOW - 24-hour deadline critical",
        "Inform insurer immediately - call helpline",
        "Document everything with photos/videos"
      ],
      warnings: [
        "Claim may be rejected if FIR not filed within 24 hours",
        "Any repairs before inspection will void claim",
        "Missing documents can delay settlement by 30+ days"
      ],
      timeline: "15-30 days after complete documentation",
      checklist: [
        { item: "Policy is active", status: "complete" },
        { item: "Incident type covered", status: "complete" },
        { item: "FIR filed", status: "missing" },
        { item: "Insurer notified", status: "pending" },
        { item: "Photos taken", status: "pending" },
        { item: "Documents submitted", status: "missing" }
      ]
    };

    return new Response(
      JSON.stringify(analysis),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});
