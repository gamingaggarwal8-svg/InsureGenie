import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface BuyingRequest {
  context: string;
  vehicleType?: string;
  budget?: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { context, vehicleType, budget }: BuyingRequest = await req.json();

    const guidance = {
      mandatory: [
        {
          title: "Third-Party Liability Insurance",
          description: "Required by law. Covers damages to third parties in accidents.",
          cost: "₹2,000 - ₹5,000/year",
          required: true
        },
        {
          title: "Personal Accident Cover",
          description: "Mandatory for owner-driver. Covers accidental death/disability.",
          cost: "₹750/year (fixed)",
          required: true
        }
      ],
      recommended: [
        {
          title: "Comprehensive Insurance",
          description: "Covers own damage, theft, natural calamities plus third-party liability.",
          cost: "₹15,000 - ₹35,000/year",
          why: "New cars are expensive to repair. Comprehensive coverage protects your investment.",
          worthIt: true
        },
        {
          title: "Zero Depreciation Cover",
          description: "Get full claim amount without depreciation deduction on parts.",
          cost: "+20% of premium",
          why: "For cars under 5 years, saves significant money on claims.",
          worthIt: true
        }
      ],
      optional: [
        {
          title: "Engine Protection",
          description: "Covers engine damage from water, oil leakage, etc.",
          cost: "+₹2,000 - ₹5,000",
          when: "If you live in flood-prone area",
          worthIt: "conditional"
        },
        {
          title: "Roadside Assistance",
          description: "Towing, flat tire, fuel delivery services.",
          cost: "+₹500 - ₹1,500",
          when: "If you drive long distances frequently",
          worthIt: "conditional"
        },
        {
          title: "Return to Invoice",
          description: "Get full invoice value if car is totaled/stolen.",
          cost: "+₹3,000 - ₹8,000",
          when: "Only for brand new cars in first year",
          worthIt: "conditional"
        }
      ],
      avoid: [
        {
          title: "Extended Warranty from Dealer",
          description: "Usually overpriced compared to manufacturer warranty extension",
          reason: "Better to evaluate after 3 years based on actual condition"
        },
        {
          title: "Consumable Cover",
          description: "Covers engine oil, coolant, nuts and bolts",
          reason: "These are low-cost items. Premium increase not worth it"
        },
        {
          title: "Key Replacement Cover",
          description: "Coverage for lost car keys",
          reason: "Rare occurrence. Better to pay out of pocket if needed"
        }
      ],
      steps: [
        "Get quotes from 3-4 insurers (compare online)",
        "Check claim settlement ratio (above 90% is good)",
        "Read policy exclusions carefully",
        "Buy directly from insurer (avoid middlemen markup)",
        "Complete within 7 days of vehicle purchase for seamless coverage"
      ],
      estimatedCost: {
        minimum: "₹2,750/year (only mandatory)",
        recommended: "₹20,000 - ₹40,000/year (comprehensive + zero depreciation)",
        note: "Actual cost varies by vehicle value, city, and driving history"
      },
      tips: [
        "Install anti-theft device for 2-5% discount",
        "Volunteer for higher deductible to reduce premium",
        "Renew before expiry to avoid losing NCB (No Claim Bonus)",
        "Don't claim for minor damages, preserve NCB for bigger savings"
      ]
    };

    return new Response(
      JSON.stringify(guidance),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});
